from setuptools import setup

setup(name='odeshp',
      version='0.1',
      description='solve ODE',
      packages=['odeshp'],
      author_email='shpeka4kaps4@mail.ru',
      zip_safe=False)
