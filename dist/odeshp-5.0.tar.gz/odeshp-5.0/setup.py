from setuptools import setup

setup(name='odeshp',
      version='5.0',
      description='solve ODE',
      packages=['odeshp'],
      author_email='shpeka4kaps4@mail.ru',
      zip_safe=False)
