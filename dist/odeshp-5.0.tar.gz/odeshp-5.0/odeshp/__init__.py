"""
:authors: danial29rus,CHERNOV,martishenya,KAHOROV

:Functions: 
    odeshp.oderk3()
    
    
    
"""
from .odeshp import oderk3

